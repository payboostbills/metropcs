import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

const AboutUs = () => {
  return (
    <div>
      <Navbar />
      <div className="px-4">
        <div className="container mx-auto my-8 p-8 bg-gray-100 rounded-lg shadow-md">
          <h1 className="text-3xl font-bold mb-4">
            Metro PCS Bill About Us Page
          </h1>
          <p className="text-gray-700 mb-6">
            At Metro PCS Bill, we are committed to providing our customers with
            continued satisfaction in managing their cellular plans. We
            understand how important staying connected is in today’s globalized
            society, and our platform makes your Metro PCS fare management
            easier and more efficient, freeing up extra time for the things that
            matter. Viewing payment or account information with our
            user-friendly online platform is easy, robust, and fast.
          </p>
          <h2 className="text-2xl font-bold mb-4">
            Why Choose Metro PCS Bill?
          </h2>
          <p className="text-gray-700 mb-6">
            At Metro PCS Bill, we are committed to providing our users with a
            seamless experience for managing their mobile plans. We understand
            how crucial it is to stay connected in today’s world, and our
            platform makes it simple and efficient to handle your Metro PCS
            bill, giving you more time for the things that matter. With our
            user-friendly website, paying bills or checking account details is
            straightforward, secure, and quick.
          </p>
          <h2 className="text-2xl font-bold mb-4">
            Why Choose Metro PCS Bill?
          </h2>
          <p className="text-gray-700 mb-6">
            Our platform is designed to help you seamlessly make changes to your
            Metro PCS account. Whether you need to review pricing, check recent
            transactions, or get help with account issues, Metro PCS Bill is
            here. We aim to provide high-quality support so that managing your
            wireless communications is hassle-free. Our platform is secure, and
            we prioritize your privacy in every transaction you make.
          </p>
          <h2 className="text-2xl font-bold mb-4">Our Commitment to Serve</h2>
          <p className="text-gray-700 mb-6">
            We're dedicated to making you smile with our easy-to-manage and
            responsive support at Metro PCS Bill. You can rely on us for
            assistance with any account issues, from billing inquiries to
            troubleshooting. We’re confident that we can help you optimize your
            cellular plan, so you have one less thing to worry about.
          </p>
          <h2 className="text-2xl font-bold mb-4">
            Your Convenience, Our Priority
          </h2>
          <p className="text-gray-700 mb-6">
            Metro PCS Bill was created with your convenience in mind, saving you
            time and giving you peace of mind. Our goal is to make account
            management effortless for you, with secure procedures and a
            dedicated team that ensures your experience is as efficient as
            possible. Thank you for choosing Metro PCS Bill as your trusted
            billing solution.
          </p>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default AboutUs;
