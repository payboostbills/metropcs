import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

const TermsAndCondition = () => {
  return (
    <>
      <Navbar />
      <div className="px-4">
        <div className="bg-white container mx-auto p-6 text-black my-4 rounded-sm">
          <h2 className="text-5xl text-center font-bold py-10">
            Metro PCS Billing Terms and Conditions
          </h2>

          <div className="pb-20 pt-6">
            <p>
              Welcome to the Metro PCS Billing website. By accessing or using
              our services, you agree to comply with these terms and conditions.
              Please read them carefully as they govern your use of our website
              and services.
            </p>

            <h2 className="font-bold text-xl mt-8">1. Acceptance of Terms</h2>
            <p>
              By using this website, you acknowledge that you have read,
              understood, and agreed to these terms. If you do not agree, please
              refrain from using our services. We reserve the right to modify
              these terms at any time. Continued use of our services indicates
              your acceptance of the revised terms.
            </p>

            <h2 className="font-bold text-xl mt-8">2. Services Provided</h2>
            <p>
              Metro PCS Billing provides customers with billing services for
              their Metro PCS accounts. Our platform allows customers to manage
              their bills, view billing history, and access account information.
              All users are responsible for providing accurate and complete
              information when creating an account or making payments.
            </p>

            <h2 className="font-bold text-xl mt-8">3. User Responsibilities</h2>
            <p>
              Users are expected to use our services responsibly. You agree not
              to engage in any activity that may harm our platform, including
              unauthorized access, data theft, or any form of fraud. Violation
              of these terms may result in immediate account suspension or
              termination.
            </p>

            <h2 className="font-bold text-xl mt-8">4. Payment Processing</h2>
            <p>
              Payments made through the Metro PCS Billing platform are processed
              securely. Users are responsible for ensuring sufficient funds are
              available in their payment method. If a payment is canceled, the
              refund may take 5 to 7 business days to process and reflect in
              your account.
            </p>

            <h2 className="font-bold text-xl mt-8">5. Account Security</h2>
            <p>
              Users must maintain the confidentiality of their account
              information. You are responsible for all activities under your
              account. If you suspect unauthorized use, please contact us
              immediately at
              <a href="tel:+18334433203" className="text-blue-500">
                {" "}
                (833) 443-3203
              </a>{" "}
              or email us at
              <a
                href="mailto:support@metropcs-billing.com"
                className="text-blue-500"
              >
                {" "}
                Support@metropcs-billing.com
              </a>
              .
            </p>

            <h2 className="font-bold text-xl mt-8">
              6. Limitation of Liability
            </h2>
            <p>
              Metro PCS Billing is not liable for any indirect, incidental, or
              consequential damages arising from your use of our services. Our
              total liability for any claims is limited to the amount you paid
              for our services. We do not guarantee uninterrupted access to our
              platform.
            </p>

            <h2 className="font-bold text-xl mt-8">7. Governing Law</h2>
            <p>
              These terms are governed by the laws of the state where Metro PCS
              Billing operates. Any disputes arising from these terms will be
              resolved in accordance with local laws.
            </p>

            <h2 className="font-bold text-xl mt-8">8. Changes to Terms</h2>
            <p>
              We reserve the right to amend these terms at any time. Users will
              be notified of any changes through our website. Continued use of
              our services after updates indicates your acceptance of the new
              terms.
            </p>

            <h2 className="font-bold text-xl mt-8">9. Contact Us</h2>
            <p>
              For questions about these terms or if you need assistance, please
              contact us at
              <a href="tel:+18334433203" className="text-blue-500">
                {" "}
                (833) 443-3203
              </a>{" "}
              or
              <a
                href="mailto:support@metropcs-billing.com"
                className="text-blue-500"
              >
                {" "}
                Support@metropcs-billing.com
              </a>
              . Our support is available 24/7. We appreciate your trust in Metro
              PCS Billing for your billing needs.
            </p>
          </div>
        </div>

        <div className="bg-white container mx-auto p-6 text-black my-4 rounded-sm">
          <h1 className="text-4xl text-center font-bold mb-4">Privacy Policy</h1>

          <h2 className="text-xl font-semibold mt-4">
            1. Information We Collect
          </h2>
          
          <p>
            We may collect personal information such as your name, email
            address, and other data necessary to provide our services.
            Non-personal information like device information and usage data may
            also be collected.
          </p>

          <h2 className="text-xl font-semibold mt-4">
            2. How We Use Your Information
          </h2>
          <p>
            We use your information to provide and improve our services,
            communicate with you, and ensure compliance with legal requirements.
          </p>

          <h2 className="text-xl font-semibold mt-4">3. Data Security</h2>
          <p>
            We implement security measures to protect your information from
            unauthorized access and disclosure.
          </p>

          <h2 className="text-xl font-semibold mt-4">
            4. Cookies and Analytics
          </h2>
          <p>
            We may use cookies and analytics tools to enhance your experience
            and gather data about our website's usage.
          </p>

          <h2 className="text-xl font-semibold mt-4">5. Third-Party Links</h2>
          <p>
            Our services may contain links to third-party websites. We are not
            responsible for their privacy practices.
          </p>

          <h2 className="text-xl font-semibold mt-4">6. Your Choices</h2>
          <p>
            You can update or delete your personal information or opt out of
            communications at any time.
          </p>

          <h2 className="text-xl font-semibold mt-4">7. Children's Privacy</h2>
          <p>
            Our services are not intended for children under 13. We do not
            knowingly collect their personal information.
          </p>

          <h2 className="text-xl font-semibold mt-4">
            8. Updates to this Policy
          </h2>
          <p>
            We may update this Privacy Policy. The latest version will be posted
            on our website.
          </p>

          <h2 className="text-xl font-semibold mt-4">9. Contact Us</h2>
          <p>
            For privacy concerns, please contact us at{" "}
            <a
              className="text-blue-500"
              href="mailto:support@metropcs-billing.com"
            >
              support@metropcs-billing.com
            </a>
            .
          </p>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default TermsAndCondition;
