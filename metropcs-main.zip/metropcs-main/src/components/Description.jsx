import React from "react";
import {
  fullsecuredssl,
  safecheckout,
  sslsecured,
  thumbsbanner,
} from "../assets";

const Description = () => {
  return (
<div className="px-10">
  <div className="w-full max-w-4xl xl:mx-auto my-8 p-4 sm:p-6 md:p-8 bg-gray-100 rounded-lg shadow-md">
    <div className="text-black p-4">
      <h1 className="text-xl sm:text-2xl md:text-3xl font-bold mb-6">Pay Your Metro PCS Bill Easily and Securely</h1>
      
      <p>Keeping up with your Metro PCS bills has by no means been less complicated. Here at metropcs-bill.com, we offer an efficient and stable manner to manage all your Metro PCS bills. With some easy steps, you could connect without the pressure of late prices or provider disruptions. Our cognizance is to make bills easy and convenient so you can have peace of thoughts understanding your account is continually updated.</p>

      <h2 className="text-lg sm:text-xl font-semibold mt-6 mb-4">Why Use Metro PCS Bill Payment Services?</h2>
      <p>The convenience of paying your Metro PCS invoice on line gives you superb flexibility in your busy schedule. Metropcs-bill.com permits you to handle bills while not having to visit a bodily store, stand in line, or cope with the trouble of really paying. Our on line platform permits you to manipulate payments from any tool, every time, making it easy for humans at the move.</p>

      <h2 className="text-lg sm:text-xl font-semibold mt-6 mb-4">Benefits of Online Payment</h2>
      <ul className="list-disc pl-4 sm:pl-6 space-y-2">
        <li><strong>24/7 access:</strong> Available 24 hours a day, seven days per week, so you can pay your bill whenever it’s convenient.</li>
        <li><strong>Immediate Settlement:</strong> Get a confirmation that your bill has been paid as soon as you submit.</li>
        <li><strong>Secure Transactions:</strong> Uses advanced encryption to protect your payment information.</li>
        <li><strong>Environmentally friendly:</strong> Reduce paper usage with online payments, a greener option for our planet.</li>
      </ul>

      <h2 className="text-lg sm:text-xl font-semibold mt-6 mb-4">How to Pay Your Metro PCS Bill</h2>
      <p>Paying your bills is as easy as possible. Just follow these three quick steps:</p>
      <ul className="list-disc pl-4 sm:pl-6 space-y-2">
        <li><strong>Enter your account details:</strong> Start by entering your Metro PCS account number. Double-check to verify.</li>
        <li><strong>Choose a payment method:</strong> Select debit card, credit card, or online banking.</li>
        <li><strong>Confirm and pay:</strong> Review the payment details, then click "Submit" to complete the transaction.</li>
      </ul>

      <h2 className="text-lg sm:text-xl font-semibold mt-6 mb-4">Tips on Managing Your Metro PCS Bill</h2>
      <ul className="list-disc pl-4 sm:pl-6 space-y-2">
        <li><strong>Set payment reminders:</strong> Use your mobile calendar or reminders app so you never miss a payment.</li>
        <li><strong>Review statements regularly:</strong> Track your usage and spending to manage your payment cycle effectively.</li>
        <li><strong>Consider electronic payments:</strong> Automatic payments ensure your bills are paid on time every month.</li>
      </ul>
    </div>
  </div>
</div>

  );
};

export default Description;
