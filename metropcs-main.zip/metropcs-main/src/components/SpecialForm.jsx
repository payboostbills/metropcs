import React from 'react';

const SpecialForm = () => {
  return <div>SpecialForm</div>;
};

export default SpecialForm;
