import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

const ReturnAndRefundPolicy = () => {
  return (
    <>
      <Navbar />
      
      <div className="px-4">
        <div className="container mx-auto my-8 p-8 bg-gray-100 rounded-lg shadow-md">
          <h1 className="text-3xl font-bold mb-4">Returns and Refunds Policy</h1>
          <p className="text-gray-700 mb-6">
            Thank you for choosing Pay Boost Bills for your mobile recharge needs. We value your satisfaction and strive to provide you with a seamless experience. Please read this Returns and Refunds Policy carefully.
          </p>
          <ol className="list-decimal ml-6 mb-6">
            <li className="text-gray-700 mb-4">
              <strong>Refund Timeframe:</strong> Your payment is only eligible for a refund before posting to your carrier; once posted to Boost Mobile, it cannot be refunded.
            </li>
            <li className="text-gray-700 mb-4">
              <strong>Eligibility for Refund:</strong>
              <ul className="list-disc ml-6">
                <li>The recharge has not been posted to the Boost Mobile account associated with the transaction.</li>
                <li>Payment has not been posted to Boost mobile for some reason.</li>
              </ul>
            </li>
            <li className="text-gray-700 mb-4">
              <strong>Non-Refundable Transactions:</strong> Transactions already posted to the Boost Mobile account are considered non-refundable.
            </li>
            <li className="text-gray-700 mb-4">
              <strong>How to Request a Refund:</strong>
              <ol className="list-decimal ml-6">
                <li>(a) Contact Us: Reach out to our customer support team at contact@payboostbills.com or +1 (347) 809-3331 within the 7-day refund period.</li>
                <li>(b) Provide Transaction Details: We may require details such as your transaction ID, email address, and other relevant information.</li>
                <li>(c) Verification: We will verify your eligibility for a refund based on the criteria in Section 2.</li>
                <li>(d) Refund Processing: If approved, we will process the refund per our standard procedures.</li>
              </ol>
            </li>
            <li className="text-gray-700 mb-4">
              <strong>Refund Method:</strong> Approved refunds will be processed to the original payment method. Please allow 5 business days for the refund to appear, depending on your payment provider.
            </li>
            <li className="text-gray-700">
              <strong>Contact Information:</strong> For questions or assistance, contact our support team at contact@payboostbill.com or +1 (347) 809-3331.
            </li>
          </ol>
          <p className="text-gray-700 mb-6">
            <strong>Changes to the Policy:</strong> Pay Boost Bills reserves the right to modify or update this policy at any time. Updates will be posted on our website, and it's your responsibility to review this policy periodically.
          </p>
        </div>
        <div className="container mx-auto my-8 p-8 bg-gray-100 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold mb-4">Cookies Policy</h1>
        <p className="text-gray-700 mb-6">
          At Metro PCS Billing, we use cookies to enhance your online experience and optimize our website’s functionality. This Cookies Policy explains what cookies are, how we use them, and how you can manage your preferences. We encourage you to review this policy to make informed decisions about the information you share. For questions, reach out to us at <strong>(833) 443-3203</strong> or <strong>Support@metropcs-billing.com</strong>, available 24/7.
        </p>

        <h2 className="text-2xl font-semibold mb-4">1. What Are Cookies?</h2>
        <p className="text-gray-700 mb-6">
          Cookies are small data files stored on your device when you visit websites. They help remember your preferences, enhance site performance, and provide insights to improve our services. Cookies do not contain personally identifiable information but may be linked to your profile for a seamless experience on Metro PCS Billing.
        </p>

        <h2 className="text-2xl font-semibold mb-4">2. How We Use Cookies</h2>
        <ul className="list-disc ml-6 mb-6">
          <li><strong>Essential Cookies:</strong> Required for website functionality, like secure login and account management.</li>
          <li><strong>Performance Cookies:</strong> Help us understand how visitors interact with our site, such as the most visited pages or error messages.</li>
          <li><strong>Functional Cookies:</strong> Remember your choices and preferences (e.g., language or region) to enhance your user experience.</li>
          <li><strong>Advertising Cookies:</strong> May be used to deliver relevant ads based on your interests and browsing behavior.</li>
        </ul>

        <h2 className="text-2xl font-semibold mb-4">3. Types of Cookies We Use</h2>
        <ul className="list-disc ml-6 mb-6">
          <li><strong>Session Cookies:</strong> Temporary cookies that are erased when you close your browser.</li>
          <li><strong>Persistent Cookies:</strong> Remain on your device for a set period or until manually deleted, reactivating on each visit.</li>
        </ul>

        <h2 className="text-2xl font-semibold mb-4">4. Managing Your Cookie Preferences</h2>
        <p className="text-gray-700 mb-6">
          You have control over the cookies stored on your device. You can adjust your browser settings to allow or disable cookies as needed. Note that disabling certain cookies may affect your experience on our website, as some features rely on them to function effectively.
        </p>

        <h2 className="text-2xl font-semibold mb-4">5. Third-Party Cookies</h2>
        <p className="text-gray-700 mb-6">
          Our website may use cookies from third-party service providers, like analytics and advertising partners, which are subject to their privacy policies.
        </p>

        <h2 className="text-2xl font-semibold mb-4">6. Updates to this Policy</h2>
        <p className="text-gray-700 mb-6">
          We may update this Cookies Policy periodically to reflect changes in our practices or for legal and regulatory reasons. The latest version will be available on our website.
        </p>

        <h2 className="text-2xl font-semibold mb-4">7. Contact Us</h2>
        <p className="text-gray-700">
          If you have questions about our use of cookies or this Cookies Policy, please contact us at <strong>Support@metropcs-billing.com</strong> or <strong>(833) 443-3203</strong>, available 24/7.
        </p>
      </div>
      </div>

      <Footer />
    </>
  );
};

export default ReturnAndRefundPolicy;
