import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

const Confirmation = () => {
  return (
    <>
      <Navbar />
      <div className="px-10">
      <div className="w-full max-w-4xl lg:w-[60rem] container mx-auto my-8 px-4 py-6 sm:p-8 bg-gray-100 rounded-lg shadow-md">
        <div className="flex flex-col items-center justify-center bg-gray-50 text-center">
          {/* Icon */}
          <div className="text-green-500 mb-4">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-10 w-10 sm:h-12 sm:w-12"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>

          {/* Confirmation Message */}
          <h1 className="text-xl sm:text-2xl font-semibold mb-4">
            Thank you for your purchase
          </h1>

          <p className="text-gray-700 mb-1 text-sm sm:text-base">
            We are required 15-20 minutes to process your order.
          </p>
          <p className="text-gray-700 mb-1 text-sm sm:text-base">
            Please do not pay again until we process your request to avoid
            double payment.
          </p>
          <p className="text-gray-700 mb-1 text-sm sm:text-base">
            You will receive order confirmation through email with details of
            your order.
          </p>
          <p className="text-gray-700 mb-4 text-sm sm:text-base">
            If you have any questions about your order, feel free to contact our
            support.
          </p>

          {/* Support Contact */}
          <p className="font-semibold text-base sm:text-lg">
            Need support for your order?
          </p>
          <p className="text-xl sm:text-2xl font-bold">(833) 443-3203</p>
        </div>
      </div>
      </div>
      <Footer />
    </>
  );
};

export default Confirmation;
