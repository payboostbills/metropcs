// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB9WT7FpW92XJK8zAWugjxGPGQDTHqNG2c",
  authDomain: "boostzone-a50c7.firebaseapp.com",
  projectId: "boostzone-a50c7",
  storageBucket: "boostzone-a50c7.appspot.com",
  messagingSenderId: "577182400876",
  appId: "1:577182400876:web:404b6ab2c44f0bb6ae7349",
  measurementId: "G-9FWN3JLBK1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default db;
