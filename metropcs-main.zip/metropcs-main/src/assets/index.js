import phonecard from './phonecard.png';
import thumbsbanner from './thumbsbanner.png';
import safecheckout from './safecheckout.png';
import sslsecured from './sslsecured.png';
import fullsecuredssl from './fullsecuredssl.png';
import pbblogo from './pbblogo.png';
import emailicon from './emailicon.png';
import visacardimg from './visacardimg.jpeg';
export {
  visacardimg,
  phonecard,
  thumbsbanner,
  safecheckout,
  sslsecured,
  fullsecuredssl,
  pbblogo,
  emailicon,
};
